const RETIRE_VERSION = 'floki-manager-v2-6-3-retired-offline';
self.addEventListener('install', (event) => { self.skipWaiting(); });
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('floki-manager-')).map((key) => caches.delete(key)));
    await self.registration.unregister();
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    clients.forEach((client) => client.postMessage({ type: 'FLOKI_SW_RETIRED', version: RETIRE_VERSION }));
  })());
});
// Sin listener fetch: ninguna navegación o recurso queda interceptado.
